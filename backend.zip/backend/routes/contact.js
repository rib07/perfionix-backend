const express = require("express");
const router = express.Router();

router.post("/", (req, res) => {
  const { name, email, message } = req.body;
  console.log("New Contact Message:", { name, email, message });

  // TODO: Save to DB or send email
  res.status(200).json({ message: "Thanks for contacting Perfionix!" });
});

module.exports = router;
